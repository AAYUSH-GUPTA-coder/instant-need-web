export type OrderStatus =
  | "PENDING"
  | "CONFIRMED"
  | "PROCESSING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED";

export interface AddressSnapshot {
  fullName: string;
  line1?: string;
  line2?: string;
  addressLine1?: string; // alias used in some contexts
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phoneNumber?: string;
}

export interface OrderItemDTO {
  id: string;
  productId: string;
  productName: string;
  sku: string;
  unitOfMeasurementSnapshot?: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
  currencyCode: string;
  imageUrl?: string;
}

export interface OrderDTO {
  id: string;
  orderNumber: string;
  status: OrderStatus;
  paymentMethod: string;
  subtotalAmount: number;
  discountAmount: number;
  shippingAmount: number;
  totalAmount: number;
  currencyCode: string;
  notes?: string;
  placedAt: string;
  updatedAt: string;
  shippingAddress: AddressSnapshot;
  items: OrderItemDTO[];
  customerName?: string;
  customerBusinessName?: string;
  invoiceUrl?: string;
}

export interface OrderListItem {
  id: string;
  orderNumber: string;
  status: OrderStatus;
  totalAmount: number;
  currencyCode: string;
  itemCount: number;
  placedAt: string;
}

export interface InlineShippingAddress {
  fullName: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phoneNumber?: string;
  saveAddress?: boolean;
}

export interface PlaceOrderRequest {
  items?: Array<{ productId: string; quantity: number }>;
  shippingAddressId?: string;
  shippingAddress?: InlineShippingAddress;
  paymentMethod?: string;
  notes?: string;
}

export interface PlaceOrderResponse {
  id: string;
  orderNumber: string;
  status: string;
  message: string;
}

export interface UpdateOrderStatusRequest {
  status: OrderStatus;
}
