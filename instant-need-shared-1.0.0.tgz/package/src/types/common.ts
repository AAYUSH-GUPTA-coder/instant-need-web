export interface PagedResponse<T> {
  items: T[];
  page: number;
  limit: number;
  total: number;
}

export function calcTotalPages(r: Pick<PagedResponse<unknown>, "total" | "limit">): number {
  return r.limit > 0 ? Math.ceil(r.total / r.limit) : 0;
}

export interface ApiError {
  status: number;
  message: string;
  timestamp: string;
  path?: string;
}
