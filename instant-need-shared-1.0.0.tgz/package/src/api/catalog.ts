import apiClient from "./client";
import type {
  CategoryDTO,
  ProductDTO,
  ProductListItem,
  ProductFilterParams,
  PricingTierDTO,
  PricingTierRequest,
  CreateProductRequest,
  UpdateProductRequest,
  PriceCheckRequest,
  PriceCheckResponse,
  PincodeMinOrderDTO,
  PincodeMinOrderRequest,
} from "../types/catalog";
import type { PagedResponse } from "../types/common";

export const catalogApi = {
  getCategories: () =>
    apiClient.get<CategoryDTO[]>("/categories").then((r) => r.data),

  getCategory: (slug: string) =>
    apiClient.get<CategoryDTO>(`/categories/${slug}`).then((r) => r.data),

  getProducts: (params?: ProductFilterParams) =>
    apiClient.get<PagedResponse<ProductListItem>>("/products", { params }).then((r) => r.data),

  getProduct: (slug: string) =>
    apiClient.get<ProductDTO>(`/products/${slug}`).then((r) => r.data),

  checkPrice: (body: PriceCheckRequest) =>
    apiClient.post<PriceCheckResponse>("/pricing/check", body).then((r) => r.data),

  getPincodeMinOrder: (pincode: string) =>
    apiClient
      .get<PincodeMinOrderDTO>("/catalog/pincode-min-order", { params: { pincode } })
      .then((r) => r.data)
      .catch((err) => {
        if (err?.response?.status === 204 || err?.response?.status === 404) return null;
        throw err;
      }),
};

export const adminCatalogApi = {
  // ── Products ─────────────────────────────────────────────────────────────
  getProducts: (params?: ProductFilterParams) =>
    apiClient
      .get<PagedResponse<ProductListItem>>("/admin/products", { params })
      .then((r) => r.data),

  getProduct: (id: string) =>
    apiClient.get<ProductDTO>(`/admin/products/${id}`).then((r) => r.data),

  createProduct: (body: CreateProductRequest) =>
    apiClient.post<ProductDTO>("/admin/products", body).then((r) => r.data),

  updateProduct: (id: string, body: UpdateProductRequest) =>
    apiClient.patch<ProductDTO>(`/admin/products/${id}`, body).then((r) => r.data),

  deleteProduct: (id: string) =>
    apiClient.delete<void>(`/admin/products/${id}`).then((r) => r.data),

  // ── Pricing tiers ─────────────────────────────────────────────────────────
  getPricingTiers: (productId: string) =>
    apiClient
      .get<PricingTierDTO[]>(`/admin/products/${productId}/pricing-tiers`)
      .then((r) => r.data),

  replacePricingTiers: (productId: string, tiers: PricingTierRequest[]) =>
    apiClient
      .put<PricingTierDTO[]>(`/admin/products/${productId}/pricing-tiers`, tiers)
      .then((r) => r.data),

  // ── Product images ────────────────────────────────────────────────────────
  uploadProductImage: (productId: string, file: File | { uri: string; name: string; type: string }) => {
    const form = new FormData();
    form.append("file", file as any);
    return apiClient
      .post<{ id: string; imageUrl: string }>(`/admin/products/${productId}/images`, form)
      .then((r) => r.data);
  },

  deleteProductImage: (productId: string, imageId: string) =>
    apiClient.delete<void>(`/admin/products/${productId}/images/${imageId}`).then((r) => r.data),

  // ── Categories ────────────────────────────────────────────────────────────
  getCategories: () =>
    apiClient.get<CategoryDTO[]>("/admin/categories").then((r) => r.data),

  createCategory: (body: Partial<CategoryDTO>) =>
    apiClient.post<CategoryDTO>("/admin/categories", body).then((r) => r.data),

  updateCategory: (id: string, body: Partial<CategoryDTO>) =>
    apiClient.patch<CategoryDTO>(`/admin/categories/${id}`, body).then((r) => r.data),

  deleteCategory: (id: string) =>
    apiClient.delete<void>(`/admin/categories/${id}`).then((r) => r.data),

  uploadCategoryImage: (id: string, file: File | { uri: string; name: string; type: string }) => {
    const form = new FormData();
    form.append("file", file as any);
    return apiClient
      .post<{ id: string; imageUrl: string }>(`/admin/categories/${id}/image`, form)
      .then((r) => r.data);
  },

  // ── Pincode rules ──────────────────────────────────────────────────────────
  listPincodeRules: () =>
    apiClient.get<PincodeMinOrderDTO[]>("/admin/pincode-rules").then((r) => r.data),

  createPincodeRule: (body: PincodeMinOrderRequest) =>
    apiClient.post<PincodeMinOrderDTO>("/admin/pincode-rules", body).then((r) => r.data),

  updatePincodeRule: (id: string, body: PincodeMinOrderRequest) =>
    apiClient.put<PincodeMinOrderDTO>(`/admin/pincode-rules/${id}`, body).then((r) => r.data),

  deletePincodeRule: (id: string) =>
    apiClient.delete<void>(`/admin/pincode-rules/${id}`).then((r) => r.data),
};
